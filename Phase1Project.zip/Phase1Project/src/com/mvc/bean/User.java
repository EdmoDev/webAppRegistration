package com.mvc.bean;

public class User {
	 private int id;
	 private RegisterBean userCredentials;
	 private String fatherName;
	 private String nationalId;
	 private String phn;
	 private String address;
	 private String country;
	 private String city;
	 private String postalCode;
	 private String hobbies;
	 public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
	public RegisterBean getUserCredentials() {
		return userCredentials;
	}
	public void setUserCredentials(RegisterBean userCredentials) {
		this.userCredentials = userCredentials;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getNationalId() {
		return nationalId;
	}
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	 
}


