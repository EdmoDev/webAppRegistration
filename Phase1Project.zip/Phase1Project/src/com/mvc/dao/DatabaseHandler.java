package com.mvc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mvc.bean.RegisterBean;
import com.mvc.bean.User;
import com.mvc.util.DBConnection;
public class DatabaseHandler {
	public User ValidateUser(RegisterBean registerBean) throws RuntimeException
    {
        String userName = registerBean.getUserName();
        String password = registerBean.getPassword();
        Connection con = null;
        PreparedStatement preparedStatement = null;  
        User user=null;
        try
        {
            con = DBConnection.createConnection();
            String query = "Select * from user_registration where userName='"+userName+"' AND password='"+password+"'"; //Insert user details into the table 'USERS'
            preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
            ResultSet resultSet = preparedStatement.executeQuery();
            RegisterBean userCredential = null;
            int id=-1;
            while (resultSet.next())
            {
            	id=resultSet.getInt("id");
            	userCredential=new RegisterBean();
            	userCredential.setFullName(resultSet.getString("fullName"));
            	userCredential.setEmail(resultSet.getString("email"));
            	userCredential.setUserName(resultSet.getString("userName"));
            	userCredential.setPassword(resultSet.getString("password"));
            }
            if (userCredential!=null)  //Just to ensure user exist or not
            {
            	user=new User();
            	user.setUserCredentials(userCredential);
            	user.setId(id);
            	try {
            		query="Select * from user_introduction where userid="+id;
                	preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
                    ResultSet result = preparedStatement.executeQuery();
                    while (result.next())
                    {
                    	user.setFatherName(result.getString("fatherName"));
                    	user.setNationalId(result.getString("nationalId"));
                    	user.setPhn(result.getString("phn"));
                    	user.setAddress(result.getString("address1"));
                    	user.setCountry(result.getString("country"));
                    	user.setCity(result.getString("city"));
                    	user.setPostalCode(result.getString("postalCode"));
                    	user.setHobbies("hobbies");
                    }
            	}
            	catch(Exception e) {
            		
            	}
                return user;
            }	 
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        throw new RuntimeException("User Not Found");  // On failure, send a message from here.
    }
	public User GetUserByID(int id) throws RuntimeException
    {
        Connection con = null;
        PreparedStatement preparedStatement = null;  
        User user=null;
        try
        {
            con = DBConnection.createConnection();
            String query = "Select * from user_registration where id="+id; //Insert user details into the table 'USERS'
            preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
            ResultSet resultSet = preparedStatement.executeQuery();
            RegisterBean userCredential = null;
            int id1=-1;
            while (resultSet.next())
            {
            	id=resultSet.getInt("id");
            	userCredential=new RegisterBean();
            	userCredential.setFullName(resultSet.getString("fullName"));
            	userCredential.setEmail(resultSet.getString("email"));
            	userCredential.setUserName(resultSet.getString("userName"));
            	userCredential.setPassword(resultSet.getString("password"));
            }
            if (userCredential!=null)  //Just to ensure user exist or not
            {
            	user=new User();
            	user.setUserCredentials(userCredential);
            	user.setId(id1);
            	try {
            		query="Select * from user_introduction where userid="+resultSet.getInt("id");
                	preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
                    ResultSet result = preparedStatement.executeQuery();
                    while (result.next())
                    {
                    	user.setFatherName(result.getString("fatherName"));
                    	user.setNationalId(result.getString("nationalId"));
                    	user.setPhn(result.getString("phn"));
                    	user.setAddress(result.getString("address1"));
                    	user.setCountry(result.getString("country"));
                    	user.setCity(result.getString("city"));
                    	user.setPostalCode(result.getString("postalCode"));
                    	user.setHobbies(result.getString("hobbies"));
                    }
            	}
            	catch(Exception e) {
            		
            	}
                return user;
            }	 
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        throw new RuntimeException("User Not Found");  // On failure, send a message from here.
    }
}


