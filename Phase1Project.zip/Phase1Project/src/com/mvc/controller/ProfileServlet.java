package com.mvc.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.RegisterBean;
import com.mvc.bean.User;
import com.mvc.dao.DatabaseHandler;
import com.mvc.dao.RegisterDao;
@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet  {
	private static final long serialVersionUID = 1L;
	
    public ProfileServlet() {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       //Copying all the input parameters in to local variables
    	int id=Integer.parseInt(request.getParameter("id"));
        String fatherName = request.getParameter("fatherName");
        String nationalID = request.getParameter("nationalID");
        String phn = request.getParameter("phn");
        String address = request.getParameter("address");
        String country = request.getParameter("country");
        String city = request.getParameter("city");
        String postalCode = request.getParameter("postalCode");
        String hobbies = request.getParameter("hobbies");
        
        User user = new User();
       //Using Java Beans - An easiest way to play with group of related data
        user.setFatherName(fatherName); 
        user.setNationalId(nationalID); 
        user.setPhn(phn); 
        user.setAddress(address); 
        user.setCountry(country); 
        user.setCity(city); 
        user.setPostalCode(postalCode); 
        user.setHobbies(hobbies);
        user.setId(id); 
        
        RegisterDao registerDao = new RegisterDao();
        DatabaseHandler d=new DatabaseHandler(); 
       //The core Logic of the Registration application is present here. We are going to insert user data in to the database.
        String userRegistered = registerDao.registerUserInformation(user);
        
        if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
        {
        	try {
        		request.setAttribute("user",d.GetUserByID(id));
        		request.getRequestDispatcher("/Home.jsp").forward(request, response);
        	}
        	catch(Exception e) {
        		request.setAttribute("errMessage", userRegistered);
                request.getRequestDispatcher("/Login.jsp").forward(request, response);
        	}
        }
        else   //On Failure, display a meaningful message to the User.
        {
           request.setAttribute("errMessage", userRegistered);
           request.getRequestDispatcher("/Home.jsp").forward(request, response);
        }
    }

}


