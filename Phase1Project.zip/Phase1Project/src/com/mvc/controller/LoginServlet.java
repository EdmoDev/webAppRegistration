package com.mvc.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.RegisterBean;
import com.mvc.bean.User;
import com.mvc.dao.DatabaseHandler;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
    public LoginServlet() {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       //Copying all the input parameters in to local variables
        String userName = request.getParameter("username");
        String password = request.getParameter("password");
        
        RegisterBean registerBean = new RegisterBean();
        registerBean.setUserName(userName);
        registerBean.setPassword(password); 
        
        DatabaseHandler database = new DatabaseHandler();
        
        try {
        	User user = database.ValidateUser(registerBean);
        	request.setAttribute("user",user);
        	request.getRequestDispatcher("/Home.jsp").forward(request, response);
        }
        catch(Exception e) {
        	request.setAttribute("errMessage", e.getMessage());
            request.getRequestDispatcher("/Login.jsp").forward(request, response);
        }
    }
}



